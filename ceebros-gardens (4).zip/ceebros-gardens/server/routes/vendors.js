const express = require('express');
const router = express.Router();
const vendorController = require('../controllers/vendorController');

router.get('/', vendorController.getAllVendors);
router.post('/', vendorController.addVendor);
router.get('/search', vendorController.searchVendors);
router.get('/min-cost', vendorController.getMinCostVendor);
router.delete('/:id', vendorController.deleteVendor);

module.exports = router;
